<?php
header('content-type:application:json;charset=utf8');
header('Access-Control-Allow-Origin:*');
header('Access-Control-Allow-Methods:POST');
header('Access-Control-Allow-Headers:x-requested-with,content-type');
?>
<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <div class="message" id="message"></div>
        <input type="text" id="receiver-id" title="Input the ID from receive.html">
        <button id="connect-button">Connect</button>
        <input type="text" id="sendMessageBox" placeholder="Enter a message..." autofocus="true" />
        <button type="button" id="sendButton">Send</button>
        <div id="dplayer"></div>
        <script src="https://unpkg.com/peerjs@1.4.7/dist/peerjs.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/flv.js/1.6.2/flv.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/dplayer/1.27.1/DPlayer.min.js"></script>
        <script type="text/javascript">
            (function () {
                var peer = null;    // Own peer object 自己的对等对象
                var conn = null;
                function initialize() {
                    // 创建自己的peer对象，连接到共享的PeerJS服务器
                    peer = new Peer(null, {
                        host: 'localhost',
                        port: 9000,
                        path: '/myapp',
                        debug: 2
                    });
                    peer.on('open', function (id) {
                        console.log('ID:' + peer.id);
                    });
                };
                function join() {
                    // Close old connection
                    // 关闭旧连接
                    if (conn) {
                        conn.close();
                    }
                    conn = peer.connect(document.getElementById("receiver-id").value, {
                        reliable: true
                    });
                    conn.on('data', function (data) {
                        addMessage("<span class=\"peerMsg\">Peer:</span> " + data);
                    });
                };
                /**
                 * Get first "GET style" parameter from href.
                 * 从href中获取第一个“Get style”参数
                 * This enables delivering an initial command upon page load.
                 * 这允许在页面加载时交付初始命令。
                 * Would have been easier to use location.hash.
                 * 使用location.hash会更简单
                 *
                 function getUrlParam(name) {
                    name = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
                    var regexS = "[\\?&]" + name + "=([^&#]*)";
                    var regex = new RegExp(regexS);
                    var results = regex.exec(window.location.href);
                    if (results == null)
                        return null;
                    else
                        return results[1];
                };
                */
                function addMessage(msg) {
                    var now = new Date();
                    var h = now.getHours();
                    var m = addZero(now.getMinutes());
                    var s = addZero(now.getSeconds());

                    if (h > 12)
                        h -= 12;
                    else if (h === 0)
                        h = 12;

                    function addZero(t) {
                        if (t < 10)
                            t = "0" + t;
                        return t;
                    };

                    document.getElementById("message").innerHTML = "<br><span class=\"msg-time\">" + h + ":" + m + ":" + s + "</span>  -  " + msg + document.getElementById("message").innerHTML;
                };
                // Listen for enter in message box
                // 收听输入消息框
                document.getElementById("sendMessageBox").addEventListener('keypress', function (e) {
                    var event = e || window.event;
                    var char = event.which || event.keyCode;
                    if (char == '13')
                    document.getElementById("sendButton").click();
                });
                // Send message
                document.getElementById("sendButton").addEventListener('click', function () {
                    if (conn && conn.open) {
                        var msg = document.getElementById("sendMessageBox").value;
                        document.getElementById("sendMessageBox").value = "";
                        conn.send(msg);
                        console.log("Sent: " + msg);
                        addMessage("<span class=\"selfMsg\">Self: </span> " + msg);
                    } else {
                        console.log('Connection is closed');
                    }
                });

                document.getElementById("connect-button").addEventListener('click', join);
                
                const dp = new DPlayer({
                    container: document.getElementById('dplayer'),
                    live: true,
                        video: {
                        type: 'flv',
                        url: 'http://127.0.0.1:7001/live/movie.flv',
                    },
                });
                initialize();
            })();
        </script>
    </body>
</html>
