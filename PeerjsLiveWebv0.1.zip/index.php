<?php
header('content-type:application:json;charset=utf8');
header('Access-Control-Allow-Origin:*');
header('Access-Control-Allow-Methods:POST');
header('Access-Control-Allow-Headers:x-requested-with,content-type');
?>
<a href="send.html">send</a>
<a href="receive.html">receive</a><br/><br/>

<a href="Msend.html">send</a>
<a href="Mreceive.html">receive</a><br/><br/>

<a href="MediaSend.html">MediaSend</a>
<a href="MediaReceive.html">MediaReceive</a><br/><br/>

<a href="MediaSendFailure.html">MediaSendFailure</a>
<a href="MediaReceiveFailure.html">MediaReceiveFailure</a><br/><br/>

<a href="MsendTest.php">sendTest</a>
<a href="MreceiveTest.php">receiveTest</a><br/><br/>