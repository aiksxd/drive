<?php
header('content-type:application:json;charset=utf8');
header('Access-Control-Allow-Origin:*');
header('Access-Control-Allow-Methods:POST');
header('Access-Control-Allow-Headers:x-requested-with,content-type');
?>
<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <div id="receiver-id" style="font-weight: bold;" title="Copy this ID to the input on send.html.">ID:</div>
        <input type="text" id="sendMessageBox" placeholder="Enter a message..." autofocus="true" />
        <button type="button" id="sendButton">Send</button>
        <div class="message" id="message"></div>
        <div id="dplayer"></div>
        <script src="https://unpkg.com/peerjs@1.4.7/dist/peerjs.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/flv.js/1.6.2/flv.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/dplayer/1.27.1/DPlayer.min.js"></script>
        <script type="text/javascript">
            (function () {
                var peer = null;    // Own peer object 自己的对等对象
                var conn = null;
                function initialize() {
                    // Create own peer object with connection to shared PeerJS server
                    peer = new Peer(null, {
                        host: 'localhost',
                        port: 9000,
                        path: '/myapp',
                        debug: 2
                    });

                    peer.on('open', function (id) {
                        console.log('ID:' + peer.id);
                        document.getElementById("receiver-id").innerHTML = "ID:<br/>" + peer.id;
                    });

                    peer.on('connection', function (c) {
                    conn = c;
                        console.log("Connected to: " + conn.peer);
                        ready(conn.peer);
                    });
                }
                    /**
                     * Triggered once a connection has been achieved.
                     * 连接完成后触发
                     * Defines callbacks to handle incoming data and connection events.
                     * 定义回调以处理传入数据和连接事件
                     */
                function ready(peerid) {
                    console.log('http://127.0.0.1:8080/' + peerid + '/live/movie.flv');
                    const dp = new DPlayer({
                        container: document.getElementById('dplayer'),
                        live: true,
                            video: {
                            type: 'flv',
                            url: 'http://127.0.0.1:8080/' + peerid + '/live/movie.flv',
                        },
                    });
                    conn.on('data', function (data) {
                        console.log("Data recieved");
                        var cueString = "<span class=\"cueMsg\">Cue: </span>";
                        addMessage("<span class=\"peerMsg\">Peer: </span>" + data);
                    });
                    conn.on('close', function () {
                        conn = null;
                    });
                }
                    
                function addMessage(msg) {
                    var now = new Date();
                    var h = now.getHours();
                    var m = addZero(now.getMinutes());
                    var s = addZero(now.getSeconds());

                    if (h > 12)
                        h -= 12;
                    else if (h === 0)
                        h = 12;

                    function addZero(t) {
                        if (t < 10)
                            t = "0" + t;
                        return t;
                    };

                    document.getElementById("message").innerHTML = "<br><span class=\"msg-time\">" + h + ":" + m + ":" + s + "</span>  -  " + msg + document.getElementById("message").innerHTML;
                }

                // Listen for enter in message box
                document.getElementById("sendMessageBox").addEventListener('keypress', function (e) {
                    var event = e || window.event;
                    var char = event.which || event.keyCode;
                    if (char == '13')
                    document.getElementById("sendButton").click();
                });
                // Send message
                document.getElementById("sendButton").addEventListener('click', function () {
                    if (conn && conn.open) {
                        var msg = document.getElementById("sendMessageBox").value;
                        document.getElementById("sendMessageBox").value = "";
                        conn.send(msg);
                        console.log("Sent: " + msg)
                        addMessage("<span class=\"selfMsg\">Self: </span>" + msg);
                    } else {
                        console.log('Connection is closed');
                    }
                });

                initialize();
            })();
        </script>
    </body>
</html>